import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class StudentManagementPro {
    public static void main(String[] args) {
        //新建一个集合以存放User对象
        ArrayList<User> list = new ArrayList<>();
        //新建一个Scanner类，接收选择信息
        Scanner sc = new Scanner(System.in);

        while (true) {
            //打印提示信息
            System.out.println("----欢迎来到学生管理系统Pro----");
            System.out.println("1.登录");
            System.out.println("2.注册");
            System.out.println("3.忘记密码");
            System.out.println("4.退出");
            System.out.println("--> 请选择您的操作：");

            //接收输入的信息
            String chose = sc.next();

            //选择流程
            switch (chose){
                case "1" -> stuLogin(list);                 //登录系统
                case "2" -> stuRegister(list);              //用户注册
                case "3" -> stuForgetPassword(list);        //忘记密码操作
                case "4" -> {                               //退出系统
                    System.out.println("---退出系统---");
                    System.exit(0);
                }
                default -> System.out.println("###-没有该选项-###");
            }
        }
    }

    /*以下为三个核心功能的方法*/
    //用户注册方法（优先实现，先注册才能验证其他功能）
    private static void stuRegister(ArrayList<User> list) {
        //提示信息
        System.out.println("----开始注册----");
        //新建一个Scanner类，获取用户名
        Scanner sc = new Scanner(System.in);

        String username;//将变量提取在循环外定义，以便后续能够使用
        while (true) {
            //获取用户名
            System.out.println("请输入一个新的用户名：");
            username = sc.next();
            //新建一个方法判断用户名的合法性，如果合法：true；如果不合法：false；
            boolean b = usernameJudgment(list,username);
            if (b){
                //如果合法，跳出循环，进入下一步
                //如果用户名不符合要求，则进入下一次循环重新输入
                break;
            }
        }

        String password2;
        while (true) {
            //输入两次密码，对两次密码进行比对
            System.out.println("请输入您的密码：");
            String password1 = sc.next();
            System.out.println("请再次输入您的密码：");
            password2 = sc.next();
            if (password1.equals(password2)){
                //相同则退出循环进入下一步
                break;
            }else {
                System.out.println("两次密码不一致，请重新输入！");
            }
        }

        String personId;
        while (true) {
            //输入身份证号
            System.out.println("请输入您的身份证号：");
            personId = sc.next();
            //定义方法对身份证号合法性进行验证，如果合法：true；如果不合法：false；
            boolean b = personIdJudgment(personId);
            if (b){
                //如果验证结果为true，则退出循环，进入下一步
                break;
            }
        }

        String phone;
        while (true) {
            //输入手机号
            System.out.println("请输入您的手机号码：");
            phone = sc.next();
            //判断手机号的合法性，如果合法：true；如果不合法：false；
            boolean b = phoneJudgment(phone);
            if (b){
                //如果验证结果为true，则退出循环，进入下一步
                break;
            }
        }

        //创建一个User对象，把接收到的属性值封装进去
        User user = new User(username,password2,personId,phone);
        //并将user添加到集合中
        list.add(user);

        //提示信息
        System.out.println("注册成功！");
    }

    //用户登录方法
    private static void stuLogin(ArrayList<User> list) {
        //提示信息
        System.out.println("----开始登录----");
        //新建Scanner类接收数据
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            //这里的警告（Condition 'i < 3' is always 'true'）
            //可能是因为在循环中存在return操作，中途结束方法会导致i永远小于3
            //验证：把‘return;’注释掉就不会继续警告了。可以忽略这个警告！

            //接收用户名
            System.out.println("用户名：");
            String username = sc.next();
            //通过判断getIndex方法的返回值，判断用户是否存在
            int index = getIndex(list, username);
            if (index < 0) {
                //不存在索引，用户不存在
                System.out.println("用户名未注册，请先注册！");
                //结束方法
                return;
            }

            //接收密码
            System.out.println("密码：");
            String password = sc.next();

            while (true) {
                //getCaptcha()调用创建验证码的方法
                String captcha = getCaptcha();

                //输入验证码
                System.out.println("请输入验证码:" + captcha);
                String enterCaptcha = sc.next();
                //判断验证码
                if (!(enterCaptcha.equalsIgnoreCase(captcha))) {
                    System.out.println("验证码错误！");
                }else {
                    System.out.println("验证码正确！");
                    break;
                }
            }

            //定义一个方法判断密码是否正确
            //以后传递参数直接传递一个整体即可，不必理会零散数据
            User u = new User(username,password,null,null);
            boolean b = checkUserPassword(list,u);
            if (b){
                System.out.println("登录成功");
                //登录成功，进入管理系统
                SystemCore ss = new SystemCore();//警告原因（暂时不必理会）：在对象的Class中只存在static静态变量，这里再new一个对象就多余了
                ss.startSystem();
                break;
            }else {
                System.out.println("密码和用户名不匹配！");
                if(i == 2){
                    System.out.println("当前电脑被锁定！");
                    return;
                }else {
                    System.out.println("您还剩"+(2-i)+"次机会！");
                }
            }
        }
    }

    //忘记密码方法
    private static void stuForgetPassword(ArrayList<User> list) {
        //提示信息
        System.out.println("++++正在找回密码++++");
        //新建Scanner接收数据
        Scanner sc = new Scanner(System.in);

        //接收用户名
        System.out.println("请输入您的用户名：");
        String username = sc.next();
        //验证用户名是否存在
        int index = getIndex(list, username);
        if (index < 0){
            //用户不存在
            System.out.println("该用户未注册！");
            return;
        }

        //接收身份证号和手机号
        System.out.println("请输入您的身份证号码：");
        String personId = sc.next();
        System.out.println("请输入您的手机号码：");
        String phone = sc.next();

        //判断该用户的身份证号和手机号是否一致----方法一：
        //创建对象存放索引所对应的地址值（getIndex获取）
        User user = list.get(index);
        if (!(user.getPersonId().equalsIgnoreCase(personId) && user.getPhone().equals(phone))){
            System.out.println("身份证与手机号不匹配！");
            return;
        }

        /*创建方法判断该用户的身份证号和手机号是否一致----方法二：
        //创建一个对象存放信息
        User user = new User(username,null,personId,phone);
        boolean b = checkIdAndPhone(list,user);
        if (!b){
            return;
        }*/
        //输入密码进行修改

        String newPassword; //警告原因（不必理会）：有相同功能代码块；
        while (true) {
            //输入两次密码，对两次密码进行比对
            System.out.println("请输入您的密码：");
            String password1 = sc.next();
            System.out.println("请再次输入您的密码：");
            newPassword = sc.next();
            if (password1.equals(newPassword)){
                //相同则退出循环进入下一步
                break;
            }else {
                System.out.println("两次密码不一致，请重新输入！");
            }
        }

        //修改密码
        user.setPassword(newPassword);//list.get(index).setPassword(newPassword);
        System.out.println("修改成功");
    }



    /*以下为配合三个核心功能实现的其他方法*/
    //手机号码合法性验证----
    private static boolean phoneJudgment(String phone) {
        //长度为11
        if (phone.length() != 11){
            System.out.println("手机号的长度必须为11位，请重新输入！");
            return false;
        }
        //不能以'0'开头-----拓展（字符转字符串）：String Str = Character.toString('c');
        if (phone.startsWith("0")){
            System.out.println("手机号不能以‘0’为开头，请重新输入！");
            return false;
        }
        //必须都是数字
        for (int i = 0; i < phone.length(); i++) {
            char c = phone.charAt(i);
            if (!(c >= '0' && c <= '9')){
                System.out.println("手机号必须是纯数字组合，请重新输入！");
                return false;
            }
        }
        return true;
    }

    //身份证号合法性验证----
    private static boolean personIdJudgment(String personId) {
        //长度为18
        if (personId.length() != 18){
            System.out.println("身份证号的长度必须为18位，请重新输入！");
            return false;
        }
        //不能以'0'开头
        if (personId.startsWith("0")){
            System.out.println("身份证号不能以‘0’为开头，请重新输入！");
            return false;
        }
        //前面17位必须是数字
        for (int i = 0; i < personId.length() - 1; i++) {
            char c = personId.charAt(i);
            if (!(c >= '0' && c <= '9')){
                System.out.println("身份证号前面17位必须是数字，请重新输入！");
                return false;
            }
        }
        //最后一位可以是数字或者大小写X
        char c2 = personId.charAt(personId.length()-1);
        if ((c2 >= '0' && c2 <= '9') || c2 == 'X' || c2 == 'x'){
            return true;
        }else {
            System.out.println("身份证号最后一位必须是数字或者大小写X，请重新输入！");
            return false;
        }
    }

    //用户名合法性验证----
    private static boolean usernameJudgment(ArrayList<User> list, String username) {
        //用户名长度必须在3-15之间
        //用一个变量接受字符串长度，不用调用两次length()，效率更高
        int length = username.length();
        if (!(length >= 3 && length <= 15)){
            //如果长度不在这个范围，返回false
            System.out.println("请重新输入一个3-15位的用户名！");
            return false;
        }
        //只能是数字加字母的组合
        //遍历的到字符串中的每一个字符
        for (int i = 0; i < username.length(); i++) {
            char c = username.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))){
                //如果不是数字加字母的组合，返回false
                System.out.println("用户名只能是字母加数字的组合，请重新输入！");
                return false;
            }
        }
        //不能是纯数字
        //遍历user中的每一个字符,计算字母的数量
        int count = 0;
        for (int i = 0; i < username.length(); i++) {
            char c = username.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')){
                count++;
                break;//如果有一个字母，直接退出循环，提高效率
            }
        }
        //通过count判断用户名是不是纯数字
        if (count == 0){
            System.out.println("用户名不能为纯数字组合，请重新输入！");
            return false;
        }
        //判断用户名的唯一性
        int index = getIndex(list,username);
        if (index >= 0){
            System.out.println("该用户已存在，请重新输入！");
            return false;
        }else {
            return true;
        }
    }

    //判断用户名的唯一性,并获取存在用户的索引值---+
    private static int getIndex(ArrayList<User> list,String username) {
        //遍历集合
        for (int i = 0; i < list.size(); i++) {
            User u = list.get(i);
            if (u.getUsername().equals(username)){
                //如果存在该用户名，返回索引
                return i;
            }
        }
        //不存在该用户
        return -1;
    }

    //验证密码与用户名是否匹配
    private static boolean checkUserPassword(ArrayList<User> list,User u) {
        //遍历集合，查找是否有与该用户名和密码匹配的账号
        for (int i = 0; i < list.size(); i++) {
            User user = list.get(i);
            if (user.getPassword().equals(u.getPassword()) && user.getUsername().equals(u.getUsername())){
                return true;
            }
        }
        return false;
    }

    //生成随机验证码
    private static String getCaptcha() {
        //创建一个集合容器存放字母
        ArrayList<Character> list = new ArrayList<>();
        //将小写英文字母存放进集合中
        for (int i = 0; i < 26; i++) {
            list.add((char)('a' + i));
        }
        //将大写英文字母存放进集合中
        for (int i = 0; i < 26; i++) {
            list.add((char)('A' + i));
        }

        //新建一个随机类
        Random r = new Random();

        //创建一个容器拼接字符串
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            //调用随机类方法生成随机索引
            int index = r.nextInt(list.size());
            //拼接到容器
            sb.append(list.get(index));
        }

        //最后生成一个数字
        int num = r.nextInt(10);
        //char n = (char)(num+48);
        sb.append(num);//拼接会把数字转换成字符串

        //把字符串变成数组，将数字打乱顺序
        char[] c = sb.toString().toCharArray();
        int newIndex = r.nextInt(c.length);
        char temp = c[newIndex];
        c[newIndex] = c[c.length-1];
        c[c.length-1] = temp;

        return new String(c);//参考String的构造方法
    }

    //判断该用户的身份证号和手机号是否一致
    //方法二：
    /*private static boolean checkIdAndPhone(ArrayList<User> list, User user) {
        for (int i = 0; i < list.size(); i++) {
            User u = list.get(i);
            if (u.getPersonId().equalsIgnoreCase(user.getPersonId()) && u.getPhone().equals(user.getPhone()) && u.getUsername().equals(user.getUsername())){
                return true;
            }
        }
        System.out.println("身份证与手机号不匹配！");
        return false;
    }*/
}
