import java.util.ArrayList;
import java.util.Scanner;

public class SystemCore {
    public static void startSystem() {
        //创建一个集合放置Student类型的数据
        ArrayList<Student> list = new ArrayList<>();

        //创建Scanner类，为下方选择流程的输入操作服务
        Scanner sc = new Scanner(System.in);

        //循环操作
        while (true){
            System.out.println("-------欢迎进入Joe学生管理系统-------");
            System.out.println("1:添加学生信息");
            System.out.println("2:删除学生信息");
            System.out.println("3:修改学生信息");
            System.out.println("4:查询所有学生信息");
            System.out.println("5:退出");
            System.out.println("请输入您的选择：");
            //输入选择
            String chose = sc.next();

            //选择流程(->格式自带break;)
            switch (chose){
                case "1" -> addStudent(list);       //添加学生信息
                case "2" -> deleteStudent(list);    //删除学生信息
                case "3" -> updateStudent(list);    //修改学生信息
                case "4" -> selectStudent(list);    //查询所有学生信息
                case "5" -> {                       //退出系统
                    System.out.println("##### 退出 #####");
                    System.exit(0);
                }
                default -> System.out.println("没有这个选项！");
            }
        }
    }


    //添加方法：对键盘录入的学生信息进行添加，要求id唯一
    //需求：list
    //返回？void
    public static void addStudent(ArrayList<Student> list){
        //打印提示信息
        System.out.println("##### 添加学生信息 #####");

        //创建Scanner类键入学生信息
        Scanner sc = new Scanner(System.in);

        //判断唯一性：如果id已经存在则需要重新输入一个新的id
        //循环直到输入一个在集合中不存在的id
        String id = null; //在循环外创建String，不然循环结束后，在循环中创建的String字符串会消失！！！
        while (true){
            //输入id
            System.out.println("输入id：");
            id = sc.next();
            //判断id唯一性
            int judgment = judgment(list,id);
            //judgment < 0代表不存在相同的id，退出循环，执行添加操作
            if (judgment < 0){
                break;
            }else {
                //id已经存在，继续输入
                System.out.println("id重复，请重新输入！");
            }
        }
        //输入姓名
        System.out.println("输入姓名：");
        String name = sc.next();
        //输入年龄
        System.out.println("输入年龄：");
        int age = sc.nextInt();
        //输入地址
        System.out.println("输入地址：");
        String address = sc.next();

        //创建一个学生对象stu,将属性值放进对象中
        Student stu = new Student(id,name,age,address);

        //再将Student类的stu对象存放进list（集合）当中
        list.add(stu);

        //提示插入成功
        System.out.println("+++++添加成功+++++");
    }


    //删除输入id对应的学生信息
    //需求：list
    //返回？void
    public static void deleteStudent(ArrayList<Student> list){
        //打印提示信息
        System.out.println("##### 删除学生信息 #####");

        //获取要删除的学生id
        Scanner sc = new Scanner(System.in);
        System.out.println("输入要删除的学生id：");
        String sid = sc.next();

        //判断id是否存在
        int index = judgment(list, sid);
        if (index < 0){
            //id不存在，不能删除对应id的学生信息
            System.out.println("id不存在，删除失败");
        }else {
            //id存在，删除
            list.remove(index);
            System.out.println("-----删除成功-----");
        }
    }


    //修改输入id对应的学生信息
    //需求：list
    //返回？void
    public static void updateStudent(ArrayList<Student> list){
        //打印提示信息
        System.out.println("##### 修改学生信息 #####");

        //获取要修改的学生id
        Scanner sc = new Scanner(System.in);
        System.out.println("输入要修改的学生id：");
        String sid = sc.next();

        //判断id是否存在
        int index = judgment(list, sid);
        if (index < 0){
            //id不存在，不能修改对应id的学生信息
            System.out.println("id不存在，修改失败");
        }else {
            //id存在，修改
            //创建学生类
            Student stu = list.get(index);//list.get(index)的地址值给了stu，
                                          //所以stu用setter方法更改属性值后存放在地址中后
                                          //集合中遍历学生信息找到这个地址打印出来的就是修改后的属性值

            //输入要修改的属性值
            System.out.println("输入姓名：");
            String name = sc.next();
            stu.setName(name);
            System.out.println("输入年龄：");
            int age = sc.nextInt();
            stu.setAge(age);
            System.out.println("输入地址：");
            String address = sc.next();
            stu.setAddress(address);

            //提示信息
            System.out.println("uuuuu 修改成功 uuuuu");
        }
    }


    //查询打印所有学生信息
    //需求：list
    //返回？void
    public static void selectStudent(ArrayList<Student> list){
        //打印提示信息
        System.out.println("##### 查询所有学生信息 #####");

        //如果没有学生信息则提示：当前无学生信息，请添加后再查询
        if (list.size() == 0){
            System.out.println("当前无学生信息，请添加后再查询!");
            return;//如果没有学生信息就退出方法
        }

        //打印表头
        System.out.println("id\t姓名\t年龄\t家庭住址");
        //如果有学生信息则打印
        for (int i = 0; i < list.size(); i++) {
            Student stu = list.get(i);
            System.out.println(stu.getId()+'\t'+stu.getName()+'\t'+stu.getAge()+'\t'+stu.getAddress());
        }
    }


    /*注意list.size()一开始就为0（因为集合里面没有元素），不会执行循环，会直接返回-1*/
    //判断id是否已经存在
    //需求：id值，list
    //返回？如果id存在则返回id所在的索引值，如果不存在则返回-1
    public static int judgment(ArrayList<Student> list, String id){
        //遍历集合寻找是否存在相同的id
        for (int i = 0; i < list.size(); i++) {
            Student stu = list.get(i);
            String judgmentId = stu.getId();
            if (judgmentId.equals(id)){
                //如果id存在则返回id所在的索引值
                return i;
            }
        }
        //如果不存在则返回-1
        return -1;
    }
}